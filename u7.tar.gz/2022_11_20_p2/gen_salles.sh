rm -f ./t_*.csv

./creneaux_salle.pl -s t1 -p 15 -d 10:00 -f 11:15
./creneaux_salle.pl -s t2 -p 15 -d 10:00 -f 11:15
./creneaux_salle.pl -s t3 -p 15 -d 10:00 -f 11:15
