#!/bin/bash

export PAS_DE_MATCH_ENTRE_EQUIPES_DU_MEME_CLUB=1

./gen_salles.sh 
./gen_poules.sh 
./affect.pl -sm save.csv -v -o matches_sur_creneaux.csv -c creneaux.csv
./choix_salles.pl  -i ./matches_sur_creneaux.csv -c creneaux.csv -v -v -v


