rm -f ./t_*.csv

./creneaux_salle.pl -s t1 -p 10 -d 10:00 -f 11:30
./creneaux_salle.pl -s t2 -p 10 -d 10:00 -f 11:30
./creneaux_salle.pl -s t3 -p 10 -d 10:00 -f 11:30
